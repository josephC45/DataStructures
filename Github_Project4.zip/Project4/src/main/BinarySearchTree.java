package main;

public class BinarySearchTree {
	private Node root;
	
	
	public BinarySearchTree(){
		root = null;			//no nodes in tree yet
	}//end constructor
	
	
	public void insert(String state, int population){
		Node newNode = new Node(state, population);
		newNode.stateName = state;
		newNode.statePopulation = population;
		
		if(root == null){
			root = newNode;
		}//end if null
		else{
			Node cur = root;
			Node parent;
			while(true){
				parent = cur;
				if(state.compareTo(cur.stateName) < 0){
					cur = cur.leftChild;
					if(cur == null){
						parent.leftChild = newNode;
						return;
					}//end if
					
				}//end if go left
				else{
					cur = cur.rightChild;
					if(cur == null){
						parent.rightChild = newNode;
						return;
						}//end if
					}//end else go right
				}//end while
			}//end else not root
		}//end insert
	
	//finds the state and returns the states population
	public int find(String state){
		Node cur = root;
		while(!cur.stateName.equalsIgnoreCase(state)){
			if(state.compareTo(cur.stateName) < 0){
				cur = cur.leftChild;
			}
			else{
				cur = cur.rightChild;
			}
			if(cur == null){
				return -1;
			}
		}
		return cur.statePopulation;
	}//end find
	
	
	//prints inorder traversal
	public void printInOrder(Node localRoot){
		if(localRoot == null)
			return;
		printInOrder(localRoot.leftChild);
		localRoot.printNode();
		printInOrder(localRoot.rightChild);
		
	}//end printInOrder
	
	//prints PreOrder traversal
	public void printPreOrder(Node localRoot){
		if(localRoot == null)
			return;
		localRoot.printNode();
		printPreOrder(localRoot.leftChild);
		printPreOrder(localRoot.rightChild);
		
	}//end printPreOrder
	
	//prints PostOrder traversal
	public void printPostOrder(Node localRoot){
		if(localRoot == null)
			return;
		printPostOrder(localRoot.leftChild);
		printPostOrder(localRoot.rightChild);
		localRoot.printNode();
		
	}//end printPostOrder
	
	//Allows for the traversal over the binary search tree
	public void Traverse(int trav){
		switch(trav){
		case 1: printInOrder(root);
				break;
		case 2: printPreOrder(root);
				break;
		case 3: printPostOrder(root);
				break;
		}
	}
	

}//end BST class

class Node{
	String stateName;
	int statePopulation;
	Node leftChild;
	Node rightChild;
	
	
	public Node(String state, int population){
		stateName = state;
		statePopulation = population;
	}//end constructor
	
	public void printNode(){
		System.out.printf("%-25s%,10d\n",stateName, statePopulation);
	}//end printNode
}//end Node class


